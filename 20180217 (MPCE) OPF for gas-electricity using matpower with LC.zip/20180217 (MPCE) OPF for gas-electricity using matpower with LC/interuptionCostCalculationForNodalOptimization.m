function [cost ] = interuptionCostCalculationForNodalOptimization( interuptionTime, interuptionCostCurve )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
t = interuptionCostCurve(1,:);
c = interuptionCostCurve(2,:);
pieceIndexHead = find(interuptionTime>=t, 1, 'last' );
pieceIndexTail = pieceIndexHead + 1;
if pieceIndexTail <= size(interuptionCostCurve,2)
    cost = c(pieceIndexHead) + (c(pieceIndexTail) - c(pieceIndexHead)) ...
    / (t(pieceIndexTail) - t(pieceIndexHead)) * (interuptionTime - t(pieceIndexHead));
else
    cost = c(end);
end

end

