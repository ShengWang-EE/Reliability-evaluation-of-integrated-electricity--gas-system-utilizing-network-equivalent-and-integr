function [ newmpc ] = mpcFailureGeneratingWtihBranch( mpc, componentsInfo,rts )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% components info ��һ��
newmpc = mpc;
numberOfGen = size(rts.gen,1); numberOfBranch= size(rts.branch,1); numberOfGsou = size(rts.Gsou,1);
numberOfPTG = size(find(mpc.GEcon(:,3)==2));
%% gen,ignore branch failures
failureGen = find(componentsInfo(:,4:(3+numberOfGen))==0);
newmpc.gen(failureGen,[2 3 4 5 9 10]) = 0;%��genʧЧ
% failureBranch = find(componentsInfo(:,(4+numberOfGen):(3+numberOfGen+numberOfBranch))==0);
%         mpc.branch(failureBranch,[6,7,8]) = 0.1;%��ֵΪ0������·���������
%% mpc.Gsou
newmpc.Gsou = mpc.Gsou;
GsouStateNumber = [2 1 1 1 1 1];
GsouState = componentsInfo(:,(4+numberOfGen+numberOfBranch):(3+numberOfGen+numberOfBranch+numberOfGsou));
smallGsouPointer = 1;
for i = 1: size(mpc.Gsou,1)
    thisGsouStateNumber = GsouStateNumber(i);
    thisGsouSuccessPart = size(find(GsouState(smallGsouPointer:(smallGsouPointer + thisGsouStateNumber -1)) == 1),2);
    newmpc.Gsou(i,[2 3 4]) = mpc.Gsou(i,[2 3 4]) / thisGsouStateNumber * thisGsouSuccessPart;
    smallGsouPointer = smallGsouPointer + thisGsouStateNumber;
end
%% gtp
gtpInfo = componentsInfo(1,(mpc.gtpIndex+3)');
gtpIndexinGEcon = find(mpc.GEcon(:,3)==1);
for i=1:size(gtpInfo,2)
    if gtpInfo(i)==0
        EbusLocation = mpc.gen(mpc.gtpIndex(i),1);
        gtpGasCapacity =  mpc.gtpCapacity(i)/200;%%%
        newmpc.GEcon(mpc.GEcon(:,2)==EbusLocation,6) = newmpc.GEcon(mpc.GEcon(:,2)==EbusLocation,6) - gtpGasCapacity;
    end
end
%% ptg
ptgInfo = componentsInfo(:,(4+numberOfGen+numberOfBranch+numberOfGsou):end);
ptgIndexinGEcon = find(mpc.GEcon(:,3)==2);
for i=1:size(ptgInfo,2)
    if ptgInfo(i)==0
        newmpc.GEcon(ptgIndexinGEcon(i),6) = 0;
    end
end

end

