 function [componentsInfo, vv] = EnumFormingScenarioV4_reduceTime(rts,mpc)
%Ϊ�˼���ʱ��Ա��õģ������׼
% no branch failure
order = 2;
%% calculating number of scenarios
ng = size(rts.gen,1); nGsou = size(rts.Gsou,1);nPTG = size(rts.ptg,1);

lambda =[(1 ./ rts.gen(:,3:4)); 
    (1 ./ rts.Gsou(:,1:2))
    (1 ./ rts.ptg(:,1:2));];
numberOfComponents = ng + nGsou + nPTG;
numberOfScenario = 0;
for i = 1:order
    numberOfScenario = numberOfScenario + nchoosek(numberOfComponents,i);
end
% col1:probability col2:0 col3:duration col4+:  0=failure 1=normal

failureComponent1st = nchoosek((1:1:numberOfComponents),1);
failureComponent2nd = nchoosek((1:1:numberOfComponents),2);
normalProbability = lambda(:,2) ./ (lambda(:,1)+lambda(:,2));
allNormal = cumprod(normalProbability); 
allNormal = allNormal(end);
componentsInfo = zeros(numberOfScenario, (3 + numberOfComponents));

for i = 1:numberOfScenario
    
    if i <= size(failureComponent1st,1)
        fc = failureComponent1st(i,1);%failure component index
        componentsInfo(i,4:end) = 1;
        componentsInfo(i, failureComponent1st(i,:)+3) = 0;
        %calculate probability 
        % ע���������Ԫ�����Ǻõĸ���
        componentsInfo(i,1) = allNormal / (lambda(fc,2)/(lambda(fc,2)+lambda(fc,1))) * lambda(fc,1)/(lambda(fc,1)+lambda(fc,2));
        
        componentsInfo(i,3) = 1/lambda(fc,2);%duration
    end

    if i > size(failureComponent1st,1) && i <= (size(failureComponent1st,1)+size(failureComponent2nd,1))
        fc1 = failureComponent2nd(i-size(failureComponent1st,1),1);fc2 = failureComponent2nd(i-size(failureComponent1st,1),2);
        componentsInfo(i,4:end) = 1;
        componentsInfo(i, failureComponent2nd(i-size(failureComponent1st,1),:)+3) = 0;
        %probability
        componentsInfo(i,1) = allNormal/(lambda(fc1,2)/(lambda(fc1,2)+lambda(fc1,1)))  /  (lambda(fc2,2)/(lambda(fc2,2)+lambda(fc2,1))) * (lambda(fc1,1)/(lambda(fc1,1)+lambda(fc1,2))) * (lambda(fc2,1)/(lambda(fc2,1)+lambda(fc2,2)));
        %duration ��Ϊ���׹��ϵĴ��ڸ���Ϊ0
        %�迼�ǹ��ϵ�Ԫ����A,B��pA����A��B�ã�pB����������
        % lambdaAB����AB����һ�����ı��ȫ����ת���ʣ�ͬ��miuAB
        pA = allNormal * (lambda(fc1,1)/(lambda(fc1,1)+lambda(fc1,2)));
        pB = allNormal * (lambda(fc2,1)/(lambda(fc2,1)+lambda(fc2,2)));
        lambdaAB = (lambda(fc1,1) * pB +lambda(fc2,1) * pA) / (pA +pB);
        miuAB = lambda(fc1,2) + lambda(fc2,2);
        componentsInfo(i,3) = 1/miuAB;
    end
end
%% add all normal state in the first line
index = numberOfScenario + 1;
componentsInfo(2:index,:) = componentsInfo(1:numberOfScenario,:);
componentsInfo(1,1) = allNormal;
componentsInfo(1,2) = 0;
componentsInfo(1,3) = 1/sum(lambda(:,2) .* componentsInfo(2:numberOfComponents+1,1));
componentsInfo(1,4:end) = 1;

%% normalize all probability
componentsInfo(:,1) = componentsInfo(:,1) / sum(componentsInfo(:,1)) ;

%% calculate the index for failure
vv.i1.normal = 1;
vv.i1.gen = 2;
% vv.i1.branch = vv.i1.gen + ng;
% vv.i1.Gsou = vv.i1.branch + ng + nl;
% vv.i1.gengen = 0;
% vv.i1.genbranch = 0;
%% move out scenario with same capacity

sameCFU = [2 2 2 2 3 3 5 6 2];
reduceByCFU = sum(2.^sameCFU - sameCFU - 1);
sameGS = [3 2];
reduceByGS = sum(2.^sameGS - sameGS - 1);
numberOfReducedScenario = reduceByCFU + reduceByGS;

componentsInfo(end-numberOfReducedScenario+1:end,:) = [];
