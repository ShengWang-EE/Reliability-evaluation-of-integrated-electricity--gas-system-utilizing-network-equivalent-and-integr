%% load curve
clear
tic
mpc=loadcase(case24GE);
mpc0 = mpc;%backup
timeScale = 0:0.5:23.5;
basicElectricityLoadCurve = [145.65	138.14	133.18	129.94	107.59	120.58	112.25	97.81	100.99	106.94	114.83	117.95	130.68	125.46	131.47	133.34	142.26	138.35	150	162.78	171.86	178.28	195.77	193.36	201.61	195.85	193.38	180.46	193.39	175.25	183.93	173.54	180.34	184.99	202.7	200.03	206.43	200.04	222.23	232.21	254.18	247.46	259.55	247.11	249.34	223.75	208.32	188.86
];
basicGasLoadCurve = [3866.31	4054.58	4085.16	4068.37	4059.76	4007.97	4041.88	4014.95	4012.49	3982.62	3972.1	3962.67	3962.52	3946.82	3977.23	4065.88	3867.39	3898.52	3967.15	3989.26	3983.85	3967.04	3814.38	3635.87	3620.08	3786.02	3910.4	4004.61	4034.82	4012.49	4003.45	4034.66	4020.21	3936.49	3705.14	3536.9	3452.67	3439.23	3405.92	3390.74	3350.87	3381.54	3406.14	3566.41	3618.26	3701.47	3729.56	3741.61
];% 24h
averageElectricity = max(basicElectricityLoadCurve); averageGas = max(basicGasLoadCurve);
caseTotalElectricityLoad = sum(mpc.bus(:,3));
caseTotalGasLoad = sum(mpc.Gbus(:,3));
electricityLoad = caseTotalElectricityLoad * basicElectricityLoadCurve / averageElectricity;
gasLoad = caseTotalGasLoad * basicGasLoadCurve / averageGas;
%% optimization 
flexiblePortion  = 0.3;
LCe = zeros(1,48);LCg = zeros(1,48);
genCost = zeros(1,48); gasCost = zeros(1,48);
LCeCost = zeros(1,48); LCgCost = zeros(1,48);
totalCost = zeros(1,48);
%%
for i = 1:48 
     mpc.LCecost = mpc0.LCecost * (1-flexiblePortion);
     mpc.bus(:,3) = mpc0.bus(:,3) * basicElectricityLoadCurve(i) / averageElectricity * 1;
     mpc.Gbus(:,3) = mpc0.Gbus(:,3) * basicGasLoadCurve(i) / averageGas * 1;
     mpc.interuptionTime = 0.5;
     result1 = runopf(mpc);
     %
        LCe(i) = sum(result1.bus(:,18));
        LCg(i) = sum(result1.Gbus(:,10));
        [genCost(i), gasCost(i), LCeCost(i), LCgCost(i)] = costDecompositon(result1, mpc);
        totalCost(i) = genCost(i) + gasCost(i) + LCeCost(i) + LCgCost(i);
end
     toc