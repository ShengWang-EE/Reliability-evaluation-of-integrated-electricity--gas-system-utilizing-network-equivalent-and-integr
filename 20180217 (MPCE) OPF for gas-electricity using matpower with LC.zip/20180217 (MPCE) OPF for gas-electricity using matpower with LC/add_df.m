function [ add_df ] = add_df( df,iPGs,iGgtp,iGptg,iLCe0,iLCg0 ,mpc)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%%
baseMVA=100;
%% calculate nodal IC curve
    nodalLCeCurve(1,:) = mpc.LCecost(1,:);
    nodalLCeCurve = [nodalLCeCurve; mpc.consumerSectorPortion(:,2:end) * mpc.LCecost(2:end,:)];
%%
unitLCeCost = zeros(size(iLCe0,2),1);unitLCgCost = zeros(size(iLCg0,2),1);

for iLCe = 1: size(iLCe0,2)
    unitLCeCost(iLCe) = unitLCeCostCalculation(mpc.interuptionTime, iLCe, nodalLCeCurve);
    ieIndex = mpc.bus(mpc.bus(:,3)~=0,1); ie = ieIndex(iLCe);
    if ismember(ie,mpc.GEcon(:,2))&&mpc.Gbus(mpc.GEcon(find(mpc.GEcon(:,2)==ie),1),3)~=0
        ig = mpc.GEcon(find(mpc.GEcon(:,2)==ie),1);
        iLCg = find(ig==mpc.Gbus(mpc.Gbus(:,3)~=0,1));
        unitLCgCost(iLCg) = unitLCgCostCalculation(unitLCeCost(iLCe));
    end
end
%û�е�����ڵ���Ϊƽ���ɱ�
noGasCostIndex = unitLCgCost==0;
unitLCgCost(noGasCostIndex) = mean(unitLCgCost(unitLCgCost~=0));
%%
df(iPGs) = mpc.Gcost;
df(iLCe0) = baseMVA * unitLCeCost;
df(iLCg0) = unitLCgCost;
%%
add_df=df;

end

