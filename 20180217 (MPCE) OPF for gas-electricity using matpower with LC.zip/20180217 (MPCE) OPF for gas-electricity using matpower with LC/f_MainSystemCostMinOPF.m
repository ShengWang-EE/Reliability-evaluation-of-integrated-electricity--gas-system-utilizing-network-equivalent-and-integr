function [expAll0] = f_MainSystemCostMinOPF(mpc)
%F_MAINSYSTEMCOSTMINOPF Summary of this function goes here
%   Detailed explanation goes here
%% import reliability data�� 
Case24ReliabillityData;%rts

mpc0 = mpc;%backup

simulationTime = 24;
% loopTimes = 1; % for enum
maxLoopTimes = 3000;
loopIndex = 0;
convergenceIndex.std = 999; 

numberOfGen = size(rts.gen,1); numberOfBranch= size(rts.branch,1);numberOfGsou = size(rts.Gsou,1);
numberOfIndices = 11;

%grab dimessions
nb = size(mpc.bus,1); 
nl = size(mpc.branch,1);
ng   = size(mpc.gen, 1);   
nGb  = size(mpc.Gbus,1);
nGl  = size(mpc.Gline,1);
nGs  = size(mpc.Gsou,1);
nGTP = size(find(mpc.GEcon(:,3)==1),1);
nPTG = size(find(mpc.GEcon(:,3)==2),1);
nLCe = size(find(mpc.bus(:,3)~=0),1);
nLCg = size(find(mpc.Gbus(:,3)~=0),1);




for i = 1: maxLoopTimes
% while convergenceIndex.std > 0.05 || loopIndex<1000%����ѭ��1000��
    
%     loopIndex = loopIndex + 1;
%     if loopIndex > maxLoopTimes
%         break
%     end
%     i= loopIndex;
    
    [componentsInfo,actualSimulationTime] = MCSformingScenarioV2(rts,mpc,simulationTime);%MCS
    % [componentsInfo,failureIndex] = EnumFormingScenarioV2(rts,mpc,simulationTime);%Enum
    numberOfscenario = size(componentsInfo,1);
    % ob initialization
    ob.success = 0;ob.unsuccessfulCase = [];ob.interuptionTime = [];ob.unsuccessfulWithGsouFault = 0;
    % indices initialization
    % maxj = 78;% number of scenario for test
    maxj = numberOfscenario; % for MCS
    nodalElectricityPrice = zeros(nb, maxj);
    nodalGasPrice = zeros(nGb, maxj);
    LCe = zeros(nb, maxj);
    LCg = zeros(nGb, maxj);
    GtpOrPtg = zeros(size(mpc.GEcon,1), maxj);
    nodalElectricityENS = zeros(nb, maxj);
    nodalGasENS = zeros(nGb, maxj);
    genCost = zeros(1, maxj);
    gasCost = zeros(1, maxj);
    LCeCost = zeros(1, maxj);
    LCgCost = zeros(1, maxj);
    for j=1:maxj %j is the index for simulation scenario
    %     numberOfscenario %ÿ��i��Ӧһ������
        failureGen = find(componentsInfo(j,4:(3+numberOfGen))==0);
        failureBranch = find(componentsInfo(j,(4+numberOfGen):(3+numberOfGen+numberOfBranch))==0);
        failureGsou = find(componentsInfo(j,(4+numberOfGen+numberOfBranch):end)==0);
        % �޸�mpc
        mpc = mpc0;
        mpc.interuptionTime = componentsInfo(j,3) - componentsInfo(j,2);

        mpc.gen(failureGen,[2 3 4 5 9 10]) = 0;%��genʧЧ
    %     mpc.branch(failureBranch,[6,7,8]) = 0.1;%��ֵΪ0������·���������
%         mpc.Gsou = GsouFailureGenerating(mpc.Gsou,componentsInfo(j,:), rts.Gsou);
        mpc.Gsou(failureGsou,[2 3 4]) = 0;%������Դ����

        result1 = runopf(mpc);

        %% ---------observe------------------------------------------------------
        ob.interuptionTime = [ob.interuptionTime; mpc.interuptionTime];
        if result1.success ==1
            ob.success = ob.success+1;
        else
            ob.unsuccessfulCase = [ob.unsuccessfulCase; j];
            if size(failureGsou,2) ~= 0
                ob.unsuccessfulWithGsouFault = ob.unsuccessfulWithGsouFault +1;
            end
        end
        %----------------------------------------------------------------------
        %% indices of each scenario extract
        % line: node, column: scenario index
        %not expectation indices (do not have to exclude unconverged case)
        nodalElectricityPrice(:,j) = result1.bus(:,14);
        nodalGasPrice(:,j) = result1.Gbus(:,11);
        LCe(:,j) = result1.bus(:,18);
        LCg(:,j) = result1.Gbus(:,10);
        GtpOrPtg(:,j) = result1.GEcon(:,7);
        nodalElectricityENS(:,j) = (componentsInfo(j,3) - componentsInfo(j,2)) * LCe(:,j);
        nodalGasENS(:,j) = (componentsInfo(j,3) - componentsInfo(j,2)) * LCg(:,j);

        [genCost(j), gasCost(j), LCeCost(j), LCgCost(j)] = costDecompositon(result1, mpc);    
    end
%% exclude the uncoveraged scenario by replacing with []
nodalElectricityPrice(:,ob.unsuccessfulCase) = [];
nodalGasPrice(:,ob.unsuccessfulCase) = [];
LCe(:,ob.unsuccessfulCase) = [];
LCg(:,ob.unsuccessfulCase) = [];
GtpOrPtg(:,ob.unsuccessfulCase) = [];
nodalElectricityENS(:,ob.unsuccessfulCase) = [];
nodalGasENS(:,ob.unsuccessfulCase) = [];
genCost(:,ob.unsuccessfulCase) = [];
gasCost(:,ob.unsuccessfulCase) = [];
LCeCost(:,ob.unsuccessfulCase) = [];
LCgCost(:,ob.unsuccessfulCase) = [];

%% calculate the expectation indices for 1 simulation
% weight
if componentsInfo(1,1) == 1 %is using MCS method
    weight = (componentsInfo(:,3) - componentsInfo(:,2)) /actualSimulationTime;
else %using enum method
    weight = componentsInfo(:,1);
end
weight = weight(1:maxj);
weight(ob.unsuccessfulCase) = [];%exclude uncoveraged case weight
if ~isempty(weight)

    averageWeight = ones(size(weight,1),1) /size(weight,1);
    expectation.nodalElectricityPrice = nodalElectricityPrice * weight;
    expectation.nodalGasPrice = nodalGasPrice * weight;
    expectation.LCe = LCe * weight;
    expectation.LCg = LCg * weight;
    expectation.GtpOrPtg = GtpOrPtg * weight;
    expectation.nodalElectricityENS = nodalElectricityENS * averageWeight;
    expectation.nodalGasENS = nodalGasENS * averageWeight;
    expectation.genCost = genCost * weight;
    expectation.gasCost = gasCost * weight;
    expectation.LCeCost = LCeCost * weight;
    expectation.LCgCost = LCgCost * weight;


    %-----store for external loopTimes-------------------
    % convert expectation struct to array, accumulate expectation index
    expAll.nodalElectricityPrice(i,:) =  expectation.nodalElectricityPrice';
    expAll.nodalGasPrice(i,:) =  expectation.nodalGasPrice';
    expAll.LCe(i,:) =  expectation.LCe';
    expAll.LCg(i,:) =  expectation.LCg';
    expAll.GtpOrPtg(i,:) =  expectation.GtpOrPtg';
    expAll.nodalElectricityENS(i,:) =  expectation.nodalElectricityENS';
    expAll.nodalGasENS(i,:) =  expectation.nodalGasENS';
    expAll.genCost(i,:) =  expectation.genCost';
    expAll.gasCost(i,:) =  expectation.gasCost';
    expAll.LCeCost(i,:) =  expectation.LCeCost';
    expAll.LCgCost(i,:) =  expectation.LCgCost';

    % calculate variance indices
    percentageSTD.nodalElectricityPrice(i,:) = std(expAll.nodalElectricityPrice(1:i,:),1) ./ mean(expAll.nodalElectricityPrice(1:i,:),1)/sqrt(i);
    percentageSTD.nodalGasPrice(i,:) = std(expAll.nodalGasPrice(1:i,:),1) ./ mean(expAll.nodalGasPrice(1:i,:),1)/sqrt(i);
    percentageSTD.LCe(i,:) = std(expAll.LCe(1:i,:),1) ./ mean(expAll.LCe(1:i,:),1)/sqrt(i);
    percentageSTD.LCg(i,:) = std(expAll.LCg(1:i,:),1) ./ mean(expAll.LCg(1:i,:),1)/sqrt(i);
    percentageSTD.GtpOrPtg(i,:) = std(expAll.GtpOrPtg(1:i,:),1) ./ mean(expAll.GtpOrPtg(1:i,:),1)/sqrt(i);
    percentageSTD.nodalElectricityENS(i,:) = std(expAll.nodalElectricityENS(1:i,:),1) ./ mean(expAll.nodalElectricityENS(1:i,:),1)/sqrt(i);
    percentageSTD.nodalGasENS(i,:) = std(expAll.nodalGasENS(1:i,:),1) ./ mean(expAll.nodalGasENS(1:i,:),1)/sqrt(i);
    percentageSTD.genCost(i,:) = std(expAll.genCost(1:i,:),1) ./ mean(expAll.genCost(1:i,:),1)/sqrt(i);
    percentageSTD.gasCost(i,:) = std(expAll.gasCost(1:i,:),1) ./ mean(expAll.gasCost(1:i,:),1)/sqrt(i);
    percentageSTD.LCeCost(i,:) = std(expAll.LCeCost(1:i,:),1) ./ mean(expAll.LCeCost(1:i,:),1)/sqrt(i);
    percentageSTD.LCgCost(i,:) = std(expAll.LCgCost(1:i,:),1) ./ mean(expAll.LCgCost(1:i,:),1)/sqrt(i);

    %calculated the convergence index, exclude LC
    convergenceIndex.std = max([max(percentageSTD.nodalElectricityPrice(i,:)),max(percentageSTD.nodalGasPrice(i,:)),...
        max(percentageSTD.LCe(i,:)),max(percentageSTD.LCg(i,:)),max(percentageSTD.GtpOrPtg(i,:)),...
        max(percentageSTD.nodalElectricityENS(i,:)),max(percentageSTD.nodalGasENS(i,:)),max(percentageSTD.genCost(i,:)),...
        max(percentageSTD.gasCost(i,:)),max(percentageSTD.LCeCost(i,:)),max(percentageSTD.LCgCost(i,:))]);
end
%    
%% nodal optimazation of LC
% EbusIndex = 1;
% nodalOptimizationResults = nodalOptimization(result1,mpc,EbusIndex);
end %loopTimes end    
% calculate expectations
expAll0.nodalElectricityPrice = mean(expAll.nodalElectricityPrice);
expAll0.nodalGasPrice = mean(expAll.nodalGasPrice);
expAll0.LCe = mean(expAll.LCe);
expAll0.LCg = mean(expAll.LCg);
expAll0.GtpOrPtg = mean(expAll.GtpOrPtg);
expAll0.nodalElectricityENS = mean(expAll.nodalElectricityENS);
expAll0.nodalGasENS = mean(expAll.nodalGasENS);
expAll0.genCost = mean(expAll.genCost);
expAll0.gasCost = mean(expAll.gasCost);
expAll0.LCeCost = mean(expAll.LCeCost);
expAll0.LCgCost = mean(expAll.LCgCost);


end

