function [ newGsou ] = GsouFailureGenerating( Gsou, componentsInfo,rtsGsou )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
newGsou = Gsou;
GsouStateNumber = [2 1 1 1 1 1];
numberOfSmallGsou = sum(GsouStateNumber);
GsouState = componentsInfo(:,(end-numberOfSmallGsou+1):end);
smallGsouPointer = 1;
for i = 1: size(Gsou,1)
    thisGsouStateNumber = GsouStateNumber(i);
    thisGsouSuccessPart = size(find(GsouState(smallGsouPointer:(smallGsouPointer + thisGsouStateNumber -1)) == 1),2);
    newGsou(i,[2 3 4]) = Gsou(i,[2 3 4]) / thisGsouStateNumber * thisGsouSuccessPart;
    smallGsouPointer = smallGsouPointer + thisGsouStateNumber;
end
end

