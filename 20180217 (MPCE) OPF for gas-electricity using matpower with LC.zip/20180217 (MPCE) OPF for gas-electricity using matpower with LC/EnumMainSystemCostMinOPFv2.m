%% ����ű�����ģ�ⲻͬ���ϳ����µ��ۺϳɱ���Сopf
clear
tic
%% import reliability data�� 
[rts] = Case24ReliabillityData();%rts
mpc=loadcase(case24GE);
mpc0 = mpc;%backup

simulationTime = 24;
loopTimes = 1; % for enum
maxLoopTimes = 1000000000;
loopIndex = 0;
convergenceIndex.std = 999; 
optimizaitonCounter = 0;
loopCounter = 0;
numberOfGen = size(rts.gen,1); numberOfBranch= size(rts.branch,1);numberOfGsou = size(rts.Gsou,1);
numberOfIndices = 11;

%grab dimessions
nb = size(mpc.bus,1); 
nl = size(mpc.branch,1);
ng   = size(mpc.gen, 1);   
nGb  = size(mpc.Gbus,1);
nGl  = size(mpc.Gline,1);
nGs  = size(mpc.Gsou,1);
nGTP = size(find(mpc.GEcon(:,3)==1),1);
nPTG = size(find(mpc.GEcon(:,3)==2),1);
nLCe = size(find(mpc.bus(:,3)~=0),1);
nLCg = size(find(mpc.Gbus(:,3)~=0),1);




for i = 1: loopTimes
% while convergenceIndex.std > 0.05 || loopIndex<1000%����ѭ��1000��
%     
%     loopIndex = loopIndex + 1;
%     if loopIndex > maxLoopTimes
%         break
%     end
%     i= loopIndex;
%     
%     [componentsInfo,actualSimulationTime] = MCSformingScenarioV4(rts,mpc,simulationTime);%MCS
    [componentsInfo,failureIndex] = EnumFormingScenarioV4(rts,mpc);%Enum
%     [componentsInfo,failureIndex] = EnumFormingScenarioV4_reduceTime(rts,mpc);%Enum
    numberOfscenario = size(componentsInfo,1);
    % ob initialization
    ob.success = 0;ob.unsuccessfulCase = [];ob.interuptionTime = [];ob.unsuccessfulWithGsouFault = 0;
    % indices initialization
    % maxj = 78;% number of scenario for test
    maxj = numberOfscenario; % for MCS
    nodalElectricityPrice = zeros(nb, maxj);
    nodalGasPrice = zeros(nGb, maxj);
    LCe = zeros(nb, maxj);
    LCg = zeros(nGb, maxj);
    GtpOrPtg = zeros(size(mpc.GEcon,1), maxj);
    nodalElectricityENS = zeros(nb, maxj);
    nodalGasENS = zeros(nGb, maxj);
    genCost = zeros(1, maxj);
    gasCost = zeros(1, maxj);
    LCeCost = zeros(1, maxj);
    LCgCost = zeros(1, maxj);
    systemElectricityENS = zeros(1, maxj);
    systemGasENS = zeros(1, maxj);
    for j=1:maxj %j is the index for simulation scenario
    %     numberOfscenario %ÿ��i��Ӧһ������
        loopCounter = loopCounter + 1;
        % �޸�mpc
        
        mpc  = mpcFailureGeneratingWithoutBranch( mpc0, componentsInfo(j,:),rts );
        mpc.interuptionTime = componentsInfo(j,3) - componentsInfo(j,2);
        sumOfElectricityGeneration = sum(mpc.gen(:,9)) + sum(mpc.GEcon(mpc.GEcon(:,3)==1,6) .* mpc.GEcon(mpc.GEcon(:,3)==1,4));
        sumOfElectricityLoad = sum(mpc.bus(:,3));
        %-----------simplified LC calculation------------------
%     if (sumOfElectricityGeneration > sumOfElectricityLoad) && isempty(find(componentsInfo(j,(4+ng):end)==0, 1))
%         LCe(:,j) = 0;
%         LCg(:,j) = 0;
%         result1.success =1;
%     else
%                 result1 = runopf(mpc); 
%         optimizaitonCounter = optimizaitonCounter +1;
%         LCe(:,j) = result1.bus(:,18);
%         LCg(:,j) = result1.Gbus(:,10);
%     end
    
    
        result1 = runopf(mpc); 
        optimizaitonCounter = optimizaitonCounter +1;
        %% ---------observe------------------------------------------------------
        ob.interuptionTime = [ob.interuptionTime; mpc.interuptionTime];
        if result1.success ==1
            ob.success = ob.success+1;
        else
            ob.unsuccessfulCase = [ob.unsuccessfulCase; j];
        end
        %----------------------------------------------------------------------
        %% indices of each scenario extract
        % line: node, column: scenario index
        %not expectation indices (do not have to exclude unconverged case)
        nodalElectricityPrice(:,j) = result1.bus(:,14);
        nodalGasPrice(:,j) = result1.Gbus(:,11);
        
%         %-----------simplified LC calculation------------------
%     if sumOfElectricityGeneration > sumOfElectricityLoad && isempty(find(componentsInfo(j,(4+ng):end)==0, 1))
%         LCe(:,j) = 0;
%         LCg(:,j) = 0;
%     else
        LCe(:,j) = result1.bus(:,18);
        LCg(:,j) = result1.Gbus(:,10);
%     end
        
        
        
        GtpOrPtg(:,j) = result1.GEcon(:,7);
        nodalElectricityENS(:,j) = (componentsInfo(j,3) - componentsInfo(j,2)) * LCe(:,j);
        nodalGasENS(:,j) = (componentsInfo(j,3) - componentsInfo(j,2)) * LCg(:,j);

        [genCost(j), gasCost(j), LCeCost(j), LCgCost(j)] = costDecompositon(result1, mpc);   
        systemElectricityENS(j) = sum(LCe(:,j));
        systemGasENS(j) = sum(LCg(:,j));
    end
%% exclude the uncoveraged scenario by replacing with []
nodalElectricityPrice(:,ob.unsuccessfulCase) = [];
nodalGasPrice(:,ob.unsuccessfulCase) = [];
LCe(:,ob.unsuccessfulCase) = [];
LCg(:,ob.unsuccessfulCase) = [];
GtpOrPtg(:,ob.unsuccessfulCase) = [];
nodalElectricityENS(:,ob.unsuccessfulCase) = [];
nodalGasENS(:,ob.unsuccessfulCase) = [];
genCost(:,ob.unsuccessfulCase) = [];
gasCost(:,ob.unsuccessfulCase) = [];
LCeCost(:,ob.unsuccessfulCase) = [];
LCgCost(:,ob.unsuccessfulCase) = [];
systemElectricityENS(:,ob.unsuccessfulCase) = [];
systemGasENS(:,ob.unsuccessfulCase) = [];
componentsInfo(ob.unsuccessfulCase,:) = [];

%% calculate the expectation indices for 1 simulation
% weight
    weight = componentsInfo(:,1);
    weight = weight /sum(weight);%����֮�ͱ�Ϊ1
% weight = (componentsInfo(:,3) - componentsInfo(:,2)) / sum((componentsInfo(:,3) - componentsInfo(:,2)));
% weight = weight(1:maxj);

averageWeight = ones(size(weight,1),1) /size(weight,1);
expectation.nodalElectricityPrice = nodalElectricityPrice * weight;
expectation.nodalGasPrice = nodalGasPrice * weight;
expectation.LCe = LCe * weight;
expectation.LCg = LCg * weight;
expectation.GtpOrPtg = GtpOrPtg * weight;
expectation.nodalElectricityENS = nodalElectricityENS * averageWeight;
expectation.nodalGasENS = nodalGasENS * averageWeight;
expectation.genCost = genCost * weight;
expectation.gasCost = gasCost * weight;
expectation.LCeCost = LCeCost * weight;
expectation.LCgCost = LCgCost * weight;
expectation.systemElectricityENS = systemElectricityENS * weight;
expectation.systemGasENS = systemGasENS * weight;

%-----store for external loopTimes-------------------
% convert expectation struct to array, accumulate expectation index
expAll.nodalElectricityPrice(i,:) =  expectation.nodalElectricityPrice';
expAll.nodalGasPrice(i,:) =  expectation.nodalGasPrice';
expAll.LCe(i,:) =  expectation.LCe';
expAll.LCg(i,:) =  expectation.LCg';
expAll.GtpOrPtg(i,:) =  expectation.GtpOrPtg';
expAll.nodalElectricityENS(i,:) =  expectation.nodalElectricityENS';
expAll.nodalGasENS(i,:) =  expectation.nodalGasENS';
expAll.genCost(i,:) =  expectation.genCost';
expAll.gasCost(i,:) =  expectation.gasCost';
expAll.LCeCost(i,:) =  expectation.LCeCost';
expAll.LCgCost(i,:) =  expectation.LCgCost';
expAll.systemElectricityENS(i,:) =  expectation.systemElectricityENS';
expAll.systemGasENS(i,:) =  expectation.systemGasENS';


%    
%% nodal optimazation of LC
% EbusIndex = 1;
% nodalOptimizationResults = nodalOptimization(result1,mpc,EbusIndex);
end %loopTimes end    
% calculate expectations
%
toc
save Enum

