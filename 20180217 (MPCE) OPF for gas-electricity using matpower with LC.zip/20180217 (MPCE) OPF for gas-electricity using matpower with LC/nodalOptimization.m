function [ nodalResults ] = nodalOptimization(systemResults,mpc, busIndex)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%% some numbers
ncs = size(mpc.LCecost,1)-1;%number of customer sectors
nb = size(mpc.bus,1);
%% get parammeters
interuptionTime = mpc.interuptionTime;
interuptionCostCurve = mpc.LCecost;
rhoE = systemResults.bus(busIndex,14);
rhoG = systemResults.Gbus(busIndex,11);
LCeEq = systemResults.bus(busIndex,18);
LCgEq = systemResults.Gbus(busIndex,10);
% ÿ���û���߿���50%
% portion of every consumer
nodalPd = mpc.bus(busIndex,3);
LCelmax = 0.5 * nodalPd * mpc.consumerSectorPortion(busIndex,2:end) * 0.8;
LCflmax = 0.5 * nodalPd * mpc.consumerSectorPortion(busIndex,2:end) * 0.2;
gasIndex = mpc.GEcon(mpc.GEcon(:,2)==busIndex,1);
if mpc.Gbus(gasIndex,3)~=0
    LCglmax = 0.5 * mpc.Gbus(gasIndex,3) * mpc.consumerSectorPortion(busIndex,2:end);
else
    LCglmax = zeros(1,ncs);
end
%% result initialization
nodalResults.LCe = zeros(nb,ncs);

%% LC equation parameters
beq = [LCeEq, LCgEq];
Aeq = zeros(2,3*ncs);
Aeq(1,1:2*ncs) = 1;Aeq(2,(2*ncs+1):3*ncs) = 1;

lb = zeros(3*ncs,1);
ub = [LCelmax';LCflmax';LCglmax';];
%% x0
x0 = zeros(3*ncs,1);    
    
%% optimization     
fun = @(x)nodalCost(x,interuptionTime, interuptionCostCurve, rhoE,rhoG,ncs);
[x,fval,exitflag,output] = fmincon(fun,x0,[],[],Aeq,beq,lb,ub);    
%% objective function 
    function [f]=nodalCost(x,interuptionTime, interuptionCostCurve, rhoE,rhoG,ncs)
        LCel = x(1:ncs);LCfl = x((ncs+1):(2*ncs));LCgl = x((2*ncs+1):(3*ncs));
        
        for i=1:ncs
            unitInteruptionCostForEL(i) = interuptionCostCalculationForNodalOptimization(interuptionTime, [interuptionCostCurve(1,:); interuptionCostCurve(1,:)]);
            unitInteruptionCostForGL(i) = unitLCgCostCalculation(unitInteruptionCostForEL);
            [~, unitInteruptionCostForFL(i)] = newUnitLCeCostCalculation(unitInteruptionCostForEL);
        end
        interuptionCost = unitInteruptionCostForEL * LCel + unitInteruptionCostForGL * LCgl + unitInteruptionCostForFL * LCfl;
        
        % LC save nodal price
        f = interuptionCost - sum(rhoE .* (LCel + LCfl)) - sum(rhoG .* (LCg));
    end
%% results output
nodalResults.f = fval;
nodalResults.LC = x;
end


