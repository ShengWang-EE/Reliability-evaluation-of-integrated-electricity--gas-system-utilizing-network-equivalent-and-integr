function [Ggtpx0] = gtpInitialValue(mpc)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
gtpEbus = mpc.GEcon(find(mpc.GEcon(:,3)==1),2);
for i = 1:size(mpc.GEcon,1)
    if mpc.GEcon(i,3) == 1 %gtp
        Ebus = mpc.GEcon(i,2);
        gtpCapacity = mpc.GEcon(i,end) * mpc.GEcon(i,4);%�����������Ҷ�Ӧ����
end

