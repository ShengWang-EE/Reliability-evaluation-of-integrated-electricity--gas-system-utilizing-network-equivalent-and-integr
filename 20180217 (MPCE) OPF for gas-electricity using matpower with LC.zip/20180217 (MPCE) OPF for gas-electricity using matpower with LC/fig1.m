clear
mpc = loadcase(case24GE);
mpc0 = mpc;

% with PTGGTP

[expectation,ob] = f_EnumMainSystemCostMinOPF(mpc);
electricityPriceWithPTGGTP = ob.electricityPrice;
gasPriceWithPTGGTP = ob.gasPrice;
 % withoout PTGGTP
 mpc.GEcon(:,6)=zeros(size(mpc.GEcon,1),1);

 [expectation,ob] = f_EnumMainSystemCostMinOPF(mpc);
electricityPriceWithoutPTGGTP = ob.electricityPrice;
gasPriceWithoutPTGGTP = ob.gasPrice;
%reshape
electricityPriceWithPTGGTP = reshape(electricityPriceWithPTGGTP,1,24*926);
gasPriceWithPTGGTP = reshape(gasPriceWithPTGGTP,1,20*926);
electricityPriceWithoutPTGGTP = reshape(electricityPriceWithoutPTGGTP,1,24*493);
gasPriceWithoutPTGGTP = reshape(gasPriceWithoutPTGGTP,1,20*493);