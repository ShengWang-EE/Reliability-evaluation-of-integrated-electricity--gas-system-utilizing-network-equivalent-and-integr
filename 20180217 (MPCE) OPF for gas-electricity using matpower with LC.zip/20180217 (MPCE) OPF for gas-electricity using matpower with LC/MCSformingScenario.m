function [componentsInfo] = MCSformingScenario(rts,mpc,simulationTime)
%MCSFORMINGSCENARIO Summary of this function goes here
%   ���ݹ���������info����������Դ����
%% Info gen
numberOfGen = size(rts.gen,1); numberOfBranch= size(rts.branch,1); 
numberOfComponents = numberOfGen + numberOfBranch;
componentsInfo = [];info1 = []; info2 = [];
for i = 1:(numberOfComponents)
    InfoTwoStateGenOrBranch = [];
    if i <= numberOfGen
        lamda = 1/rts.gen(i,3); mu = 1/rts.gen(i,4);
    else
        lamda = rts.branch((i-numberOfGen),1)/8760; mu = 1/rts.branch((i-numberOfGen),2);
    end
    %Suppose it starts from the best state: state 1, 
    InfoTwoStateGenOrBranch(1,1)= 1;    %% State number, 1 represents normal state, 0 is failure state
    InfoTwoStateGenOrBranch(1,2)= 0;    %% State start time
    InfoTwoStateGenOrBranch(1,3)= 0;    %% State end time, this value is unknown
    Total_Dur = 0;
    iter =1;          
    
    while Total_Dur < simulationTime 

      state_no = InfoTwoStateGenOrBranch(iter,1);
      switch state_no
          case 1
              if  lamda >0
                a1 = log(rand(1));
                b1 =  lamda;  %% Transition rate 
                Dur = - a1 /b1;%ֻ��2״̬��������
              else    
                Dur = 10^10;      
              end 
          case 0
              if  mu >0 
                a2 = log(rand(1));
                b2 =  mu;  %% Transition rate 
                Dur = - a2 /b2;%�޸�
              else    
                Dur = 10^10;      
              end
      end
      InfoTwoStateGenOrBranch(iter,3) = InfoTwoStateGenOrBranch(iter,2) + Dur;  
        Total_Dur = InfoTwoStateGenOrBranch(iter,3);   
        if Total_Dur < simulationTime   
          iter = iter +1;
          InfoTwoStateGenOrBranch(iter,1)= 1-InfoTwoStateGenOrBranch((iter-1),1);    %% State number, �����1���0�������0���1
          InfoTwoStateGenOrBranch(iter,2)= InfoTwoStateGenOrBranch((iter-1),3);    %% State start time
          InfoTwoStateGenOrBranch(iter,3)= 0;    %% State end time, this value is unknown
        end 
        InfoTwoStateGenOrBranch(:,4) = InfoTwoStateGenOrBranch(:,1);
    end 
%    InfoGenOrBranch{i} = InfoTwoStateGenOrBranch; 
%% merge info1 and info2
    info2 = InfoTwoStateGenOrBranch;
if i>1
    ok = 1;
    pointer1 = 1;  %% for the first unit, state pointer
    pointer2 = 1;  %% for the second unit, state pointer
    iter =1;
    StateNumber1 = size(info1,1);  %������״̬����   
    StateNumber2 = size(info2,1); 
    componentIndex = i+2;%info1������
    while ok 
      if iter ==1
         componentsInfo(iter,1)=1;  %% State number
         componentsInfo(iter,2)=0;  %% Starting time
      end   

      if info1(pointer1,3) <= info2(pointer2,3) %�����ж�������������״̬���ӣ�����ö�٣��Ǹ���unitʵ��ģ�������ʱ��˳�����

         if pointer1 == StateNumber1  %% Point of the first unit moves to the last state 

              componentsInfo(iter,3)=info1(pointer1,3);  %% This is the state end time  
              componentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
              componentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);  %% info1�кܶ���״̬��info2ֻ��һ��
              ok=0;  

         else 
              componentsInfo(iter,3)=info1(pointer1,3);
              componentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
              componentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
              pointer1 = pointer1+1;

              iter = iter +1;
              componentsInfo(iter,1)=iter;%״̬�����±�
              componentsInfo(iter,2)= info1(pointer1,2);
         end     


      else
         if pointer2 == StateNumber2  %% Point of the second unit moves to the last state

             componentsInfo(iter,3)=info2(pointer2,3);   %% This is the state end time   
             componentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
             componentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
             ok=0; 
          else
             componentsInfo(iter,3)=info2(pointer2,3);
             componentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
             componentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
             pointer2 = pointer2+1;


             iter = iter +1;
             componentsInfo(iter,1)=iter;
             componentsInfo(iter,2)= info2(pointer2,2);
         end   
      end    
    end
    info1 = componentsInfo;
end  
    if i == 1
        info1 = InfoTwoStateGenOrBranch;
    end
end
a=1
end
