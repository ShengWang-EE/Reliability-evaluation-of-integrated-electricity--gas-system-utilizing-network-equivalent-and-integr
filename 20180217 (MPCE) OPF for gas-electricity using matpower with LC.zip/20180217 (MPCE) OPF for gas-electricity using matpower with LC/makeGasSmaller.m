function [newmpc] = makeGasSmaller(mpc,times)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%make gas smaller by xx times.
mpc.Gbus(:,3) = mpc.Gbus(:,3) ./ times;%gas load
mpc.Gline(:,3:5) = mpc.Gline(:,3:5)./times;

end

