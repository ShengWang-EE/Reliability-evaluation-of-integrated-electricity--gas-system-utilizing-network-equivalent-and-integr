%% �����ܹ���GTPPTG�ı���
% gtpElectricityIndex = mpc.GEcon(mpc.GEcon(:,3)==1,2);
% gtpGasIndex = mpc.GEcon(mpc.GEcon(:,3)==2,1);
% ptgElectricityIndex = mpc.GEcon(mpc.GEcon(:,3)==2,2);
% ptgGasIndex = mpc.GEcon(mpc.GEcon(:,3)==2,1);
clear
load EnumWithoutPTGGTP
gtpptgIndex = [];gtpptgGEIndex = [];
for i=1:size(mpc.GEcon,1)
    if (mpc.GEcon(i,3)==1)||(mpc.GEcon(i,3)==2)
        gtpptgIndex = [gtpptgIndex;mpc.GEcon(i,1:3)];
        gtpptgGEIndex = [gtpptgGEIndex; i];
    end
end
expAll0 = expAll;
plotGraph.nodalGasPrice = -expAll0.nodalGasPrice(gtpptgIndex(:,1));
plotGraph.nodalElectricityPrice = expAll0.nodalElectricityPrice(gtpptgIndex(:,2));
plotGraph.LCg = -expAll0.LCg(gtpptgIndex(:,1));
plotGraph.LCe = expAll0.LCe(gtpptgIndex(:,2));
plotGraph.GasENS = -expAll0.nodalGasENS(gtpptgIndex(:,1));
plotGraph.ElectricityENS = expAll0.nodalElectricityENS(gtpptgIndex(:,2));


ptgGEIndex = find(mpc.GEcon(:,3)==2);
gtpGEIndex = find(mpc.GEcon(:,3)==1);
expAll0.GtpOrPtg(ptgGEIndex) = -expAll0.GtpOrPtg(ptgGEIndex);
% expAll0.GtpOrPtg(gtpGEIndex) = 200*expAll0.GtpOrPtg(gtpGEIndex);
plotGraph.GTPorPTG = expAll0.GtpOrPtg(gtpptgGEIndex);




