function [allComponentsInfo, actualSimulationTime] = MCSformingScenarioV4(rts,mpc,simulationTime)
% ���ݹ���������info��������Դ����,��࿼�Ƕ��ף�����������ϵĳ�����
% ���е�һ����ԴΪ��״̬�������Ϊ��״̬��
% ����PTG���ϡ���֮ǰ��Ȼ������GTP���ϣ�����û���������ȼ�������������ֵ��
% ������branch���ϳ��������������Ի᲻����
%% Info gen
numberOfGen = size(rts.gen,1); numberOfGsou = size(rts.Gsou,1);
numberOfPTG = size(find(mpc.GEcon(:,3)==2),1);
numberOfComponents = numberOfGen + numberOfGsou + numberOfPTG;
allComponentsInfo = [];info1 = []; info2 = [];
for i = 1:(numberOfComponents)
    InfoOfComponent = [];
    % calculate lamda and mu according to different types of components
    %components order: gen, branch, Gsou
    if i <= numberOfGen
        lamda = 1/rts.gen(i,3); mu = 1/rts.gen(i,4);
    elseif i > (numberOfGen) && i<= (numberOfGen + numberOfGsou)
        lamda = 1/rts.Gsou(i-numberOfGen,1); mu = 1/rts.Gsou(i-numberOfGen,2);
    else 
        lamda = 1/rts.ptg(i-numberOfGen-numberOfGsou,1); mu = 1/rts.ptg(i-numberOfGen-numberOfGsou,2);
    end
    %determine the first state
    if rand(1) < lamda/(lamda+mu)
        InfoOfComponent(1,1)= 0;    %% State number, 1 represents normal state, 0 is failure state
    else
        InfoOfComponent(1,1)= 1;
    end
    
    InfoOfComponent(1,2)= 0;    %% State start time
    InfoOfComponent(1,3)= 0;    %% State end time, this value is unknown
    Total_Dur = 0;
    iter =1;          
    
    while Total_Dur < simulationTime 

      state_no = InfoOfComponent(iter,1);
      switch state_no
          case 1
              if  lamda >0
                a1 = log(rand(1));
                b1 =  lamda;  %% Transition rate 
                Dur = - a1 /b1;%ֻ��2״̬��������
              else    
                Dur = 10^10;      
              end 
          case 0
              if  mu >0 
                a2 = log(rand(1));
                b2 =  mu;  %% Transition rate 
                Dur = - a2 /b2;%�޸�
              else    
                Dur = 10^10;      
              end
      end
      InfoOfComponent(iter,3) = InfoOfComponent(iter,2) + Dur;  
        Total_Dur = InfoOfComponent(iter,3);   
        if Total_Dur < simulationTime   
          iter = iter +1;
          InfoOfComponent(iter,1)= 1-InfoOfComponent((iter-1),1);    %% State number, �����1���0�������0���1
          InfoOfComponent(iter,2)= InfoOfComponent((iter-1),3);    %% State start time
          InfoOfComponent(iter,3)= 0;    %% State end time, this value is unknown
        end 
        InfoOfComponent(:,4) = InfoOfComponent(:,1);
    end 
%    InfoGenOrBranch{i} = InfoTwoStateGenOrBranch; 
%% merge info1 and info2
    info2 = InfoOfComponent;
    if i>1
        ok = 1;
        pointer1 = 1;  %% for the first unit, state pointer
        pointer2 = 1;  %% for the second unit, state pointer
        iter =1;
        StateNumber1 = size(info1,1);  %������״̬����   
        StateNumber2 = size(info2,1); 
        componentIndex = i+2;%info1������
        while ok 
          if iter ==1
             allComponentsInfo(iter,1)=1;  %% State number
             allComponentsInfo(iter,2)=0;  %% Starting time
          end   

          if info1(pointer1,3) <= info2(pointer2,3) %�����ж�������������״̬���ӣ�����ö�٣��Ǹ���unitʵ��ģ�������ʱ��˳�����

             if pointer1 == StateNumber1  %% Point of the first unit moves to the last state 

                  allComponentsInfo(iter,3)=info1(pointer1,3);  %% This is the state end time  
                  allComponentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
                  allComponentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);  %% info1�кܶ���״̬��info2ֻ��һ��
                  ok=0;  

             else 
                  allComponentsInfo(iter,3)=info1(pointer1,3);
                  allComponentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
                  allComponentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
                  pointer1 = pointer1+1;

                  iter = iter +1;
                  allComponentsInfo(iter,1)=iter;%״̬�����±�
                  allComponentsInfo(iter,2)= info1(pointer1,2);
             end     


          else
             if pointer2 == StateNumber2  %% Point of the second unit moves to the last state

                 allComponentsInfo(iter,3)=info2(pointer2,3);   %% This is the state end time   
                 allComponentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
                 allComponentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
                 ok=0; 
              else
                 allComponentsInfo(iter,3)=info2(pointer2,3);
                 allComponentsInfo(iter,4:componentIndex)=info1(pointer1,4:componentIndex);
                 allComponentsInfo(iter,(componentIndex+1)) = info2(pointer2,4);
                 pointer2 = pointer2+1;


                 iter = iter +1;
                 allComponentsInfo(iter,1)=iter;
                 allComponentsInfo(iter,2)= info2(pointer2,2);
             end   
          end    
        end
        info1 = allComponentsInfo;
    end  
    if i == 1
        info1 = InfoOfComponent;
    end
end
allComponentsInfo(end,3) = simulationTime;
%% ��β��һ������ʱ��Ϊ0������״̬��ֹ�ռ�
addComponentsInfo = [allComponentsInfo(size(allComponentsInfo,1),1)+1, 2400, 2400,ones(1,size(allComponentsInfo,2)-3)];
allComponentsInfo = [allComponentsInfo; addComponentsInfo];
actualSimulationTime = simulationTime;
%% exclude more than 2nd failure scenarios

excludedScenarioIndex = [];
for i=1:size(allComponentsInfo,1)
    numberOfFailure = size(find(allComponentsInfo(i,4:end)==0),2);
    if numberOfFailure > 2
        excludedScenarioIndex = [excludedScenarioIndex;i];
    end
end
allComponentsInfo(excludedScenarioIndex,:) = [];
actualSimulationTime = sum(allComponentsInfo(:,3) - allComponentsInfo(:,2));

end
