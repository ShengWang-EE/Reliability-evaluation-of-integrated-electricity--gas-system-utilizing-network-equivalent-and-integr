%% ���ڼ����ڲ�ͬ����ˮƽ�����пɿ���
%% varying loads
clear
tic
mpc = loadcase(case24GE);
mpc0 = mpc;
%% 
% kE = 0.5:0.1:2;
% kG = kE;
kGTP = 0:0.1:3;%1.5times is enough for GTP
kPTG =0:0.1:3;
% kGTP = 1;

unsuccessfulCase = [];
allTimeResults.nodalElectricityPrice=[];
allTimeResults.nodalGasPrice=[];
allTimeResults.LCe=[];
allTimeResults.LCg=[];
allTimeResults.GtpOrPtg=[];
allTimeResults.nodalElectricityENS=[];
allTimeResults.nodalGasENS=[];
allTimeResults.genCost=[];
allTimeResults.gasCost=[];
allTimeResults.LCeCost=[];
allTimeResults.LCgCost=[];
allTimeResults.systemElectricityENS=[];
allTimeResults.systemGasENS=[];
point = 0;
allGenCost = zeros(size(kGTP,2),size(kPTG,2));
allGasCost = zeros(size(kGTP,2),size(kPTG,2));
allLCeCost = zeros(size(kGTP,2),size(kPTG,2));
allLCgCost = zeros(size(kGTP,2),size(kPTG,2));
allCost = zeros(size(kGTP,2),size(kPTG,2));
allSystemElectricityENS = zeros(size(kGTP,2),size(kPTG,2));
allSystemGasENS = zeros(size(kGTP,2),size(kPTG,2));
nodalEB7ENS = zeros(size(kGTP,2),size(kPTG,2));
nodalEB15ENS = zeros(size(kGTP,2),size(kPTG,2));
nodalGB15ENS = zeros(size(kGTP,2),size(kPTG,2));
convergePercentage = zeros(size(kGTP,2),size(kPTG,2));
for i = 1:size(kGTP,2)
    for j = 1:size(kPTG,2)
        if i==j
        point = point + 1;
        % varying load level
%         mpc.bus(:,3) = mpc0.bus(:,3) * kE(i);
%         mpc.Gbus(:,3) = mpc0.Gbus(:,3) * kG(j);
        %varying PTGGTP
        mpc.GEcon(mpc.GEcon(:,3)==1,6) = mpc0.GEcon(mpc.GEcon(:,3)==1,6) * kGTP(i);
        mpc.GEcon(mpc.GEcon(:,3)==2,6) = mpc0.GEcon(mpc.GEcon(:,3)==2,6) * kPTG(j);
        % reset initialization
%         mpc.gen(:,2) = mpc0.gen(:,2) * kE(i);
%         mpc.Gsou(:,2) = mpc0.Gsou(:,2) * kG(j);
    %test---------------
%     mpc.Gbus(:,5) = 0;
%     [expAll0] = f_MainSystemCostMinOPF(mpc);
    [expAll0,ob] = f_EnumMainSystemCostMinOPF(mpc);
    allTimeResults.nodalElectricityPrice = [allTimeResults.nodalElectricityPrice; expAll0.nodalElectricityPrice];
    allTimeResults.nodalGasPrice = [allTimeResults.nodalGasPrice; expAll0.nodalGasPrice];
    allTimeResults.LCe = [allTimeResults.LCe; expAll0.LCe];
    allTimeResults.LCg = [allTimeResults.LCg; expAll0.LCg];
    allTimeResults.GtpOrPtg = [allTimeResults.GtpOrPtg; expAll0.GtpOrPtg];
    allTimeResults.nodalElectricityENS = [allTimeResults.nodalElectricityENS; expAll0.nodalElectricityENS];
    allTimeResults.nodalGasENS = [allTimeResults.nodalGasENS; expAll0.nodalGasENS];
    allTimeResults.genCost = [allTimeResults.genCost; expAll0.genCost];
    allTimeResults.gasCost = [allTimeResults.gasCost; expAll0.gasCost];
    allTimeResults.LCeCost = [allTimeResults.LCeCost; expAll0.LCeCost];
    allTimeResults.LCgCost = [allTimeResults.LCgCost; expAll0.LCgCost];
    allTimeResults.systemElectricityENS = [allTimeResults.systemElectricityENS; expAll0.systemElectricityENS];
    allTimeResults.systemGasENS = [allTimeResults.systemGasENS; expAll0.systemGasENS];
    unsuccessfulCase = [unsuccessfulCase; 0; 0; 0; ob.unsuccessfulCase];
    %------------specially interested-----------------------
    allGenCost(i,j) = expAll0.genCost;
    allGasCost(i,j) = expAll0.gasCost;
    allLCeCost(i,j) = expAll0.LCeCost;
    allLCgCost(i,j) = expAll0.LCgCost;
    allCost(i,j) = expAll0.genCost + expAll0.gasCost + expAll0.LCeCost + expAll0.LCgCost;
    allSystemElectricityENS(i,j) = expAll0.systemElectricityENS;
    allSystemGasENS(i,j) = expAll0.systemGasENS;
    nodalEB7ENS(i,j) = expAll0.LCe(7) * 24;
    nodalEB15ENS(i,j) = expAll0.LCe(15) * 24;
    nodalGB15ENS(i,j) = expAll0.LCg(15) * 24;
    convergePercentage(i,j) = size(ob.unsuccessfulCase,1);
        end
    end
end

%% emerge EENSs

elapseTime = toc
save TV2
