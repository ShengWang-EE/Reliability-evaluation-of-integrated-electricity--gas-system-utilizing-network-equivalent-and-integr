clear
tic
opt=mpoption('mips.max_it',1000);
mpc = loadcase(case24GE);
% mpc = makeGasSmaller(mpc); %����gas��С��֮���Ƿ��и���
%% 
mpc.interuptionTime = 0.1;
test_result=runopf(mpc,opt);
%% 
% flag=zeros(120,2);index = 0;
% for interuptionTime = 0:0.2:24
%     index = index + 1;
%     mpc.interuptionTime = interuptionTime;
%     testResult = runopf(mpc);
%     flag(index,2)=unitLCeCostCalculation(interuptionTime, 1, mpc);
%     flag(index,1) = testResult.success;
% 
% end
%%
toc
