function [portion, newUnitLCeCost] = newUnitLCeCostCalculation(unitLCecost)
% Summary of this function goes here
%   ��LCe�ɱ��ֽ�Ϊ����
%consumption %cost
CC = [
    26 8 %space heating
    4 2 %hot tap water
    8 4 %cooling
    4 1 %electrical boilers
    9 2 %cooking
    49 83]; %other electric devices
flexibleLoadIndex = [1 2 4 5]; nonFlexibleLoadIndex = [3 6];
consumptionEL = sum(CC(flexibleLoadIndex,1));costEL = sum(CC(flexibleLoadIndex,2));
consumptionFL = sum(CC(nonFlexibleLoadIndex,1));costFL = sum(CC(nonFlexibleLoadIndex,2));
newUnitLCeCost = [costEL/consumptionEL; costFL/consumptionFL] * unitLCecost;
portion = [consumptionEL, consumptionFL] / 100;
%%
newUnitLCeCost = newUnitLCeCost(2);
end

