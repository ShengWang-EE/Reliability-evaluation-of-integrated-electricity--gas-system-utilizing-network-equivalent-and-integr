clear
mpc=loadcase(case24GE);Case24ReliabillityData;
%% plot interuption cost
for i=2:7
    for j=3:5
        mpc.LCecost(i,j) = mpc.LCecost(i,j).*mpc.LCecost(1,j);
    end
end
xlswrite('temp.xlsx',mpc.LCecost);
%% plot gtpptg
GB = [2 7 10 13 14 15 16];EB = [7 10 5 1 2 15 16];
result2 = [expectation.LCe(EB) expectation.GtpOrPtg(GB) expectation.LCg(GB)];