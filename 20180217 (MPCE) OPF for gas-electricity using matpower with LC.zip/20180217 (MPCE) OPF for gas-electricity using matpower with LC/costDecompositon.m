function [ genCost, gasCost, LCeCost, LCgCost] = costDecompositon( result, mpc )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% ��ȡ����
PGs = result.Gsou(:,5);
Pg = result.gen(:,2);
LCe = result.bus((mpc.bus(:,3)>0),18);
LCg = result.Gbus(mpc.Gbus(:,3)>0,10);

%% calculate nodal IC curve
    nodalLCeCurve(1,:) = mpc.LCecost(1,:);
    nodalLCeCurve = [nodalLCeCurve; mpc.consumerSectorPortion(:,2:end) * mpc.LCecost(2:end,:)];
    %%
unitLCeCost = zeros(size(LCe,1),1);unitLCgCost = zeros(size(LCg,1),1);
ig=1;
for ie = 1: size(LCe,1)
    unitLCeCost(ie) = unitLCeCostCalculation(mpc.interuptionTime, ie, nodalLCeCurve);
    if ismember(ie,mpc.GEcon(:,2))&&mpc.Gbus(mpc.GEcon(find(mpc.GEcon(:,2)==ie),1),3)~=0
        unitLCgCost(ig) = unitLCgCostCalculation(unitLCeCost(ie));
        ig=ig+1;
    end
end
%%

genCost = sum(totcost(mpc.gencost, Pg));
gasCost = PGs'*mpc.Gcost;
LCeCost = sum(unitLCeCost .* LCe);
LCgCost = sum(unitLCgCost .* LCg);


end

