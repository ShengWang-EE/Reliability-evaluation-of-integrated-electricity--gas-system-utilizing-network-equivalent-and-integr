clear
Case24ReliabillityData;%rts
mpc=loadcase(case24GE);
mpc0 = mpc;
numberOfGen = size(rts.gen,1); numberOfBranch= size(rts.branch,1);numberOfGsou = size(rts.Gsou,1);
j=1;
componentsInfo = [110,1499.83062928309,1514.06991234568,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1];
failureGen = find(componentsInfo(j,4:(3+numberOfGen))==0);
        failureBranch = find(componentsInfo(j,(4+numberOfGen):(3+numberOfGen+numberOfBranch))==0);
        failureGsou = find(componentsInfo(j,(4+numberOfGen+numberOfBranch):end)==0);
        % �޸�mpc
        mpc = mpc0;
        mpc.interuptionTime = componentsInfo(j,3) - componentsInfo(j,2);

        mpc.gen(failureGen,[2 3 4 5 9 10]) = 0;%��genʧЧ
%         mpc.branch(failureBranch,[6,7,8]) = 0.1;%��ֵΪ0������·���������
        mpc.Gsou = GsouFailureGenerating(mpc.Gsou,componentsInfo(j,:), rts.Gsou);
%         mpc.Gsou(failureGsou,[2 3 4]) = 0;%������Դ����

        result2 = runopf(mpc);