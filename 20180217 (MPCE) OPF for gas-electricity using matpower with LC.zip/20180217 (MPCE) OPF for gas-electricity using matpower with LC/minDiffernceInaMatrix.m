function [minDiffernce] = minDiffernceInaMatrix(A)
%ISEQUALINAMATRIX Summary of this function goes here
%   
A = A(:);
sizeA = size(A,1);
difference = [];
for i = 1:sizeA
    for j = 1:sizeA
        if i~=j
            difference = [difference abs(A(i)-A(j))];
        end
    end
end
minDiffernce = min(difference);
end

