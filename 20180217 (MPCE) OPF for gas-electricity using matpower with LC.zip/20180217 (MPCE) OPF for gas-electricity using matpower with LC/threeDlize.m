[newallSystemElectricityENS] = f_threeDlize(allSystemElectricityENS,kGTP,kPTG);
[newallSystemGasENS] = f_threeDlize(allSystemGasENS,kGTP,kPTG);
function [newCost] = f_threeDlize(allCost,kGTP,kPTG)
pointer = 0; newCost = [];
for i=1:size(kGTP,2)
    for j = 1:size(kPTG,2)
        pointer = pointer + 1;
        newCost(pointer,1) = i;newCost(pointer,2) = j;
        newCost(pointer,3) = allCost(i,j);
    end
end
end
        